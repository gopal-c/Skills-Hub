# SkillsHub Web App — UI Kit

A high-fidelity recreation of SkillsHub's HR-facing web app. Built to
demonstrate the design system in motion. Components are **cosmetic**, not
production — they show the visual surface, not the data layer.

## What's here

- `index.html` — interactive demo screen. Renders the **search → results**
  view with a working query input, filter chips, and animated reasoning
  cards. Clicking a result opens its profile detail.
- `App.jsx` — top-level shell (sidebar + canvas).
- `SearchBar.jsx` — the natural-language search input.
- `ResultCard.jsx` — single candidate result with score + reasoning.
- `ProfilePanel.jsx` — right-side slide-over profile view.
- `Sidebar.jsx` — left nav with sections.

## Screen coverage

This kit demonstrates the **Search & match** flow, the product's main
moment. The other surfaces (resume ingest queue, employee directory, auth)
are not built — see the deck for what they include. Add them as the
brand expands.

## Loading

```html
<link rel="stylesheet" href="../../colors_and_type.css">
<link rel="stylesheet" href="app.css">
<script src="https://unpkg.com/react@18.3.1/umd/react.development.js" …></script>
<script src="https://unpkg.com/react-dom@18.3.1/umd/react-dom.development.js" …></script>
<script src="https://unpkg.com/@babel/standalone@7.29.0/babel.min.js" …></script>
<script src="https://unpkg.com/lucide@latest/dist/umd/lucide.min.js"></script>
<script type="text/babel" src="Sidebar.jsx"></script>
<!-- … -->
<script type="text/babel" src="App.jsx"></script>
```
