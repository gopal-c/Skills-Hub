---
name: skillshub-design
description: Use this skill to generate well-branded interfaces and assets for SkillsHub, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the `README.md` file within this skill, and explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## Quick orientation

- **What SkillsHub is** — AI skills intelligence platform for HR. Resume ingest + Gemini extraction + semantic natural-language search with explainable reasoning.
- **Audience** — HR leads, hiring managers, sponsors. *Warm but credible.*
- **Token file** — `colors_and_type.css` is the single source of truth. Always `@import` it, never hard-code hexes.
- **Mark + wordmark** — `assets/logo-mark.svg` and `assets/logo-wordmark[-dark].svg`.
- **Brand illustration** — soft radial glows in `assets/glow-{indigo,coral,teal,amber}.png`. Use `mix-blend-mode: screen` on dark backgrounds.
- **UI kit** — `ui_kits/web-app/` shows the canonical search + results + profile screen.

## Hard rules

- Indigo (`#8B7BE8`) carries the brand. Coral/teal/amber are co-equal data colors.
- No pure black — `--ink-900` (`#151634`) is the deepest surface.
- No left-border-accent cards, no bluish-purple gradient hero backgrounds, no isometric SaaS illustration.
- Iconography is Lucide, 1.5 stroke, currentColor.
- Editorial moments use Instrument Serif (italic for the lyrical bits). Everything else is Geist sans.
- Shadows are indigo-tinted, never neutral grey.
